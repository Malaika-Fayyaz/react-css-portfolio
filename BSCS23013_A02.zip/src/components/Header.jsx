import { AppBar, Toolbar, Typography, IconButton, Avatar } from '@mui/material';
import { usePageTitle } from '../context/PageTitleContext';

function Header() {
  const { title } = usePageTitle(); // Now this will work

  return (
    <AppBar position="fixed" sx={{ 
      width: { xs: '100%', sm: 'calc(100% - 250px)' },
      backgroundColor: 'var(--secondary)',
      borderBottom: '2px solid var(--primary)'
    }}>
      <Toolbar>
        <Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
          {title}
        </Typography>
        <Avatar src="/mypicture2.jpg" />
      </Toolbar>
    </AppBar>
  );
}

export default Header;